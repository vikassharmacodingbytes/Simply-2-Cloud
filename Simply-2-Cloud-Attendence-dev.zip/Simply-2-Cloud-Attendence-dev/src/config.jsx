// const API_BASE_URL = "http://192.168.29.78:8000";
// const API_ROUTE_URL = "http://192.168.29.78:8000";  

const API_BASE_URL = "https://vikassharma.pythonanywhere.com";
const API_ROUTE_URL = "https://vikassharma.pythonanywhere.com";

export {
    API_BASE_URL,
    API_ROUTE_URL
}
