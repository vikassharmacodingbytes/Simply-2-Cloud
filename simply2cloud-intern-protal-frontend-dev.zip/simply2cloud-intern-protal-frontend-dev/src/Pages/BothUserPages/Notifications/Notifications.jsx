import React from 'react'
import NoDataPage from '../../../Component/NoDataPage/NoDataPage'

const UserNotifications = () => {
  return (
    <div className='h-[80vh]'>
<NoDataPage domain={"No Notification"} height={"h-full"} />   
    </div>
)
}

export default UserNotifications
