import React from 'react'
import SelectBatch from '../../../../../ComonComponent/SelectBatch/SelectBatch'

const SelectBatchPost = () => {
  
  return (
    <div>
      <SelectBatch 
        route={"student-attendence"}
    />
    </div>
  )
}

export default SelectBatchPost
