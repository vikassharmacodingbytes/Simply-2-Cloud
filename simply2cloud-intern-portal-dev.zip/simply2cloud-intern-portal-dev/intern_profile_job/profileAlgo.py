


def filterGoodProfiles(profiles):
    # for i in profiles:
    #     # print(i)
    # return []
    pass

