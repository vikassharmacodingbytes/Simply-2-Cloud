from django.apps import AppConfig


class AvailableSkillsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'available_skills'
