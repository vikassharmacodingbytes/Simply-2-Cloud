// Define the base API URL here
const API_BASE_URL = 'https://emailmanagement.pythonanywhere.com'; 
const API_ROUTE_URL = 'https://simply2cloud-intern-protal-frontend.vercel.app'; 

// const API_BASE_URL = 'http://localhost:8000'; 
// const API_ROUTE_URL = 'http://localhost:5173'; 
const API_SOCKET_URL = 'https://chat-socket-node-production.up.railway.app';

export { API_ROUTE_URL, API_SOCKET_URL };

export default API_BASE_URL;
