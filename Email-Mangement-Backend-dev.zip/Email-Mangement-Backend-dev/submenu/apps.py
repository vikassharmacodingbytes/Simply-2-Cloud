from django.apps import AppConfig


class SubmenuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'submenu'
