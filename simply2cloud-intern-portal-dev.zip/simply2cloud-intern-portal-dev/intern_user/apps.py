from django.apps import AppConfig


class InternUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'intern_user'
