from django.apps import AppConfig


class EmaillogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'emaillog'
