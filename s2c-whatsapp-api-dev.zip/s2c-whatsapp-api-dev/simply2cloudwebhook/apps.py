from django.apps import AppConfig


class Simply2CloudwebhookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'simply2cloudwebhook'
