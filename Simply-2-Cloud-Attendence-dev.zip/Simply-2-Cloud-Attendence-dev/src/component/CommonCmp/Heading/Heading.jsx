import React from 'react'

const Heading = ({ text1, text2 }) => {
  return (
    <div className='my-10'>
    <h1 className='text-4xl text-center text-gray-700 font-bold  text-gray md:mx-0 md:my-0mx-4'>Simply 2 Cloud 
    <br />Attendence</h1>
  </div>
  )
}

export default Heading
