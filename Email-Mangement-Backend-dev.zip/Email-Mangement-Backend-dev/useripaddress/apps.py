from django.apps import AppConfig


class UseripaddressConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'useripaddress'
