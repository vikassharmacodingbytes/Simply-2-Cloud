from django.apps import AppConfig


class DisputeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dispute'
