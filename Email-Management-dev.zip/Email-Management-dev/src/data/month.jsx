const months_arr = [
    {
        "number" : "01",
        "value" : "January",
        "max" : "31",
    },
    {
        "number" : "02",
        "value" : "Febuary",
        "max" : "28"
    },
    {
        "number" : "03",
        "max" : "31",
        "value" : "March"
    },
    {
        "number" : "04",
        "value" : "April",
        "max" : "30",
    },
    {
        "number" : "05",
        "max" : "31",
        "value" : "May"
    },
    {
        "number" : "06",
        "max" : "30",
        "value" : "June"
    },
    {
        "number" : "07",
        "max" : "31",
        "value" : "July"
    },
    {
        "number" : "08",
        "max" : "31",
        "value" : "August"
    },
    {
        "number" : "09",
        "max" : "30",
        "value" : "September"
    },
    {
        "number" : "10",
        "max" : "31",
        "value" : "October"
    },
    {
        "number" : "11",
        "max" : "30",
        "value" : "November"
    },
    {
        "number" : "12",
        "max" : "31",
        "value" : "December"
    },
]

export default months_arr;