const addUserIp = [
    {
        'type': 'dynamicoption',
        'id': 'customer_id',
        'name': 'customer_id',
        'required': true,
        'placeholder': 'Customer Id',
        'icon' : <Factory className={iconCss}/>
    },
    {
        'type': 'text',
        'id': 'CompanyName',
        'name': 'company_name',
        'required': true,
        'placeholder': 'Company Name',
        'icon' : <Factory className={iconCss}/>
    },
]