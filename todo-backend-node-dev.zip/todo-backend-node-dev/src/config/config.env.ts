interface configInterface {
    private_key : string,
    dbUri : string, 
    port : number
}

const configraution : configInterface = {
    private_key : "private_key_of_munna_bahi",
    dbUri : "mongodb+srv://positivemind123456789:wBtx1FsUh2TjbjVO@cluster0.m52smdp.mongodb.net/",
    port : 3000
}

export default configraution;