from django.apps import AppConfig


class AttendenceTracerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'attendence_tracer'
